﻿create table pessoa_civil (
	id int(10) unsigned not null auto_increment,
	nome varchar(60) not null,
	cpf int(11)not null,
	telefone int(12)not null,
	endereco varchar(80) not null,
	cidade varchar(60) not null,
	estado varchar(2) not null,	
	primary key (id),
	unique key uk_cpf (cpf)
) engine=InnoDB auto_increment=1 DEFAULT CHARSET=utf8;

create table id_emergencia (
	id int(10) unsigned not null auto_increment,
	id_pessoa int(12)not null,
	primary key (id)
	) engine=InnoDB auto_increment=1 DEFAULT CHARSET=utf8;